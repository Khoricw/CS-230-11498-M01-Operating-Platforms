package com.gamingroom;

/**
 * Base class for all entities (Game, Team, Player).
 * 
 * @author Khori Cohen-Welch
 * @date 08/09/2024
 * @instructor Dr. Belcher
 */
public abstract class Entity {
    protected long id;  // Unique identifier for each entity
    protected String name;  // Name of the entity

    // Constructor to initialize the entity with an ID and name
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getter method to retrieve the ID
    public long getId() {
        return id;
    }

    // Getter method to retrieve the name
    public String getName() {
        return name;
    }

    // Override the toString method to provide a string representation of the entity
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " [id=" + id + ", name=" + name + "]";
    }
}
