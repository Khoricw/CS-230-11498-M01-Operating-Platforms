package com.gamingroom;

/**
 * A class representing a game with an ID and name.
 * 
 * @author Khori Cohen-Welch
 * @date 08/09/2024
 * @instructor Dr. Belcher
 */
public class Game extends Entity {
    
    // Constructor to initialize the game with an ID and name
    public Game(long id, String name) {
        super(id, name);
    }
}