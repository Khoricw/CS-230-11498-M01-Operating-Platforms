package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Singleton class to manage game data.
 * 
 * @author Khori Cohen-Welch
 * @date 08/09/2024
 * @instructor Dr. Belcher
 */
public class GameService {
    private static GameService instance;  // Singleton instance of GameService
    private List<Game> games;  // List to hold all the games

    // Private constructor to prevent instantiation
    private GameService() {
        games = new ArrayList<>();
    }

    // Method to get the singleton instance of GameService
    public static synchronized GameService getInstance() {
        if (instance == null) {
            instance = new GameService();  // Create the instance if it doesn't exist
        }
        return instance;
    }

    // Method to add a new game to the list
    public Game addGame(String name) {
        // Check if the game name is already in use
        if (isNameInUse(name, games.iterator())) {
            throw new IllegalArgumentException("Game name must be unique.");
        }
        // Create a new game and add it to the list
        Game game = new Game(games.size() + 1, name);
        games.add(game);
        return game;
    }

    // Method to get the total number of games
    public int getGameCount() {
        return games.size();
    }

    // Method to retrieve a game by its index in the list
    public Game getGame(int index) {
        return games.get(index);
    }

    // Helper method to check if a name is already in use
    private boolean isNameInUse(String name, Iterator<? extends Entity> iterator) {
        while (iterator.hasNext()) {
            if (iterator.next().getName().equalsIgnoreCase(name)) {
                return true;  // Return true if the name is found
            }
        }
        return false;  // Return false if the name is not found
    }
}
