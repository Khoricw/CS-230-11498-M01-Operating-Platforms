package com.gamingroom;

/**
 * Application start-up program.
 * 
 * @author Khori Cohen-Welch
 * @date 08/09/2024
 * @instructor Dr. Belcher
 */
public class ProgramDriver {
    
    public static void main(String[] args) {
        
        // Obtain reference to the singleton instance of GameService
        GameService service = GameService.getInstance();

        System.out.println("\nTesting game data initialization...");

        try {
            // Add games to the service
            Game game1 = service.addGame("Game #1");
            System.out.println(game1);
            Game game2 = service.addGame("Game #2");
            System.out.println(game2);

            // Attempt to add a game with a duplicate name
            Game game3 = service.addGame("Game #1");
            System.out.println(game3);
        } catch (IllegalArgumentException e) {
            // Print the exception message if a duplicate name is used
            System.out.println(e.getMessage());
        }

        // Test the singleton behavior using the SingletonTester class
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}
