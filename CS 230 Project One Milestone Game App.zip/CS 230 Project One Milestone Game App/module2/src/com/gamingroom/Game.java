package com.gamingroom;

/**
 * A class representing a game with an ID and name.
 * 
 * @author coce@snhu.edu
 */
public class Game {
    private long id;
    private String name;

    /**
     * Constructor with an identifier and name.
     * 
     * @param id the ID of the game
     * @param name the name of the game
     */
    public Game(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the ID of the game
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name of the game
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Game [id=" + id + ", name=" + name + "]";
    }
}
