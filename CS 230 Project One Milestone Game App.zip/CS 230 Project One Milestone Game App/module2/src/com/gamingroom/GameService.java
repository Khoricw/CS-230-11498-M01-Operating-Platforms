package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * Singleton class to manage game data.
 * 
 * @author coce@snhu.edu
 */
public class GameService {
    private static GameService instance;
    private List<Game> games;

    // Private constructor to prevent instantiation
    private GameService() {
        games = new ArrayList<>();
    }

    /**
     * Get the single instance of GameService.
     * 
     * @return the singleton instance
     */
    public static synchronized GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    /**
     * Add a game to the service.
     * 
     * @param name the name of the game
     * @return the created Game object
     */
    public Game addGame(String name) {
        Game game = new Game(games.size() + 1, name); // Auto-increment ID based on size
        games.add(game);
        return game;
    }

    /**
     * Get the number of games.
     * 
     * @return the number of games
     */
    public int getGameCount() {
        return games.size();
    }

    /**
     * Get a game by index.
     * 
     * @param index the index of the game
     * @return the Game object at the specified index
     */
    public Game getGame(int index) {
        return games.get(index);
    }
}
