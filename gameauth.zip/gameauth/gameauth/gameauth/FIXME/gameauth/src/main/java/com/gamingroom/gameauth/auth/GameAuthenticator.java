package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    // Map to hold valid usernames and their associated roles
    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(), // No roles for guest
        "user", ImmutableSet.of("USER"), // "USER" role for "user"
        "admin", ImmutableSet.of("ADMIN", "USER") // "ADMIN" and "USER" roles for "admin"
    );

    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {
        // Check if the username exists in VALID_USERS and the password matches
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) {
            // FIXME: Finish the authorize method based on BasicAuth Security Example for new GameUser
            return Optional.of(new GameUser(credentials.getUsername(), VALID_USERS.get(credentials.getUsername())));
        }
        // Return empty if authentication fails
        return Optional.empty();
    }
}
